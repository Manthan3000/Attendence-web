#An attendence marking app for my class
technologies used 
    HTML
    CSS
    JavaScript
